/*
 * FreeRTOS_Project_EC.c
 *
 * Created: 2/24/2017 1:31:20 AM
 * Author : heman
 */ 

/* Include Library Headers */
#include "ADC_Lib.h"
#include "UART_Lib.h"

/* Include FreeRTOS files */
#include "FreeRTOS/FreeRTOS.h"
#include "FreeRTOS/task.h"
#include "FreeRTOS/queue.h"

/* Priority definitions for tasks application. */
#define mainADC_UART_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )
#define mainLED_TASK_PRIORITY			( tskIDLE_PRIORITY + 1 )

/* Stack Size for Task */
#define UART_ADC_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE )

/* The rate at which data is sent to the queue, specified in milliseconds. */
#define mainQUEUE_SEND_FREQUENCY_MS			( 200 / portTICK_RATE_MS )
#define mainQUEUE_RECEIVE_FREQUENCY_MS		( 100 / portTICK_RATE_MS )
#define min_DELAY_MS						( 50 / portTICK_RATE_MS )

// Macros for task
#define NoBlockTime		( ( unsigned long ) 0 )
#define WaitingTime		( ( TickType_t ) 5/portTICK_PERIOD_MS )

/* Macros for POWER LED */
#define POWER_LED_PORT				( PORTB )
#define POWER_LED_PORT_DDR			( DDRB )
#define powerLED					( 0 )
#define ToggleLED( port, x )		( port ^= 1<<x  )

/* Definitions for data types */
typedef uint16_t VADC_RESULT_SIZE_t;
typedef	VADC_RESULT_SIZE_t	QueueItemSize;

/*--------- Local Prototypes ----------*/
/* Task for ADC measurement */
static void vAdcMeasurementTask( void *pvParameters );
/* Task for UART Transmission */
static void vTransmitAdcMeasurementTask( void *pvParameters );

/* Handles For ADC, UASRT Tasks. */
TaskHandle_t xADC_Handle = NULL;
TaskHandle_t xUART_Handle = NULL;

/* Queue for ADC Task. */
#define mainADC_UART_TASK_Queue_Length	( (UBaseType_t) 8 )

/* Handle for ADC_UART Queue */
QueueHandle_t QueueHandle;

/* Task Creation Function */
static void vPowerLedTask( void *pvParameters );
static void vADC_UART_Task( UBaseType_t uxPriority, portSTACK_TYPE stackSize, UBaseType_t QueueLength );


/* ADC data channel */
#define ADC_CHANNEL		( (uint8_t) 0 )

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(void)
{
  /* Creating the tasks. */
  /* Led Flashing Tasks */
  xTaskCreate( vPowerLedTask, "LEDTask", configMINIMAL_STACK_SIZE, NULL, mainLED_TASK_PRIORITY, NULL );
  /* Task to Send ADC values to UART */
  vADC_UART_Task( mainADC_UART_TASK_PRIORITY, UART_ADC_TASK_STACK_SIZE, mainADC_UART_TASK_Queue_Length );

  /* Start the RTOS scheduler, this function should not return as it causes the execution
     context to change from main() to one of the created tasks. */
  vTaskStartScheduler();
  
  /* Should never reach here */
  return 0;
}
/* End */


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*  Name: vADC_UART_Task
	Description: Task initializer
	Arguments: uxPriority, StackSize, QueueLength
 */
static void vADC_UART_Task( UBaseType_t uxPriority, portSTACK_TYPE StackSize, UBaseType_t QueueLength ) {
	
	// Create queue
	QueueHandle = xQueueCreate( QueueLength, (unsigned portBASE_TYPE) sizeof(QueueItemSize) );

	if ( NULL == QueueHandle ) {
		// Do Nothing and return
		return;
	}

	// Initialize Peripherals
	ADC_Init( 4 );
	UART_Init( 8, 0, 0, 0, 0 );

	// Create task
	xTaskCreate( vAdcMeasurementTask, "ADC_MEASUREMENT", StackSize, ADC_CHANNEL, uxPriority, xADC_Handle );
	xTaskCreate( vTransmitAdcMeasurementTask, "UART_TRANSMISSION", StackSize, NULL, uxPriority, xUART_Handle );

	/* Using Handle to Delete the Task. */
	if( (xADC_Handle != NULL) || (xUART_Handle != NULL) )
	{
		vTaskDelete(xADC_Handle);
		vTaskDelete(xUART_Handle);
	}
	
	/* Send Initialization Message to Screen */
	UART_Print("FreeRTOS embeddedcrab.com DEMO\r\n");
}


/*  Name: vPowerLedTask
	Description: Led Flashing Task, power led
	Arguments:
 */
static void vPowerLedTask( void *pvParameters ){

	// Set PORT pin as Output
	POWER_LED_PORT_DDR |= 1<<powerLED;
	// Infinite loop for lashing LED
	for( ; ; ){
		// Toggle LED
		ToggleLED( POWER_LED_PORT, powerLED );
		vTaskDelay(500);

		#if !configUSE_PREEMPTION
		   /* If cooperative scheduler is used, yield the CPU */
		   taskYIELD();
		#endif
	}
}


/* Task Prototypes */
static void vAdcMeasurementTask( void *pvParameters ){
	// Local parameters
	VADC_RESULT_SIZE_t adcValue = 0;

	portTickType xNextWakeTime;
	/* Initialize xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	for( ; ; ){
		/* Wait for some time */
		vTaskDelayUntil( &xNextWakeTime, mainQUEUE_SEND_FREQUENCY_MS );
		
		/*Read out conversion results*/
		adcValue = ADC_GetChannelValue( *(uint8_t *)pvParameters );
		
		/* Send data to Queue */
		xQueueSend( QueueHandle, &adcValue, 0 );
	}
}

static void vTransmitAdcMeasurementTask( void *pvParameters ){
	// Local parameters
	VADC_RESULT_SIZE_t adcValue = 0;
	uint8_t delimiter = 13;

	/* Initialize xNextWakeTime - this only needs to be done once. */
	portTickType xNextWakeTime = xTaskGetTickCount();

	for( ; ; ){
		/* Receive data from queue */
		if(( xQueueReceive( QueueHandle, &adcValue, 0 ) == pdPASS) ){
			UART_PrintNumDynamic( adcValue );
			UART_Transmit( delimiter );
		}
		else{
			vTaskDelayUntil( &xNextWakeTime, mainQUEUE_RECEIVE_FREQUENCY_MS );
		}
	}
}


