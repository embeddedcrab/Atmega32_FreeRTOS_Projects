/*
 * USART_Lib.h
 *
 * Created: 10/13/2016 12:23:34 PM
 *  Author: heman
 */ 


#ifndef UART_LIB_H_
#define UART_LIB_H_

// include standard headers
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <avr/io.h>
#define F_CPU	8000000UL

// uncomment to use double speed mode
//#define useDoubleSpeedMode

#define USARTDummy		( (char) '\0' )
#define BPS				9600UL
#define BAUD			( ( F_CPU / ( 16 * BPS ) ) - 1 )


// initialization functions
extern void UART_Init( uint8_t charSize, bool mode, bool parity, bool stopBits, bool polarity );
		
// transmission functions
extern void UART_Transmit( const char data );
extern void UART_Print( const char *data );
extern void UART_PrintN( const char *data, uint8_t len );
// receiving functions
extern char UART_Receive( void );
extern char * UART_Scan( uint8_t length );
extern void UART_ScanN( uint8_t length );		// receives data till terminating character is not received and send back to tx pin
		
extern void UART_PrintNumDynamic ( uint16_t num );
extern void UART_PrintNum ( uint16_t num );
		
// interrupt functions
extern void UART_InterruptEnable ( uint8_t select );

#endif /* USART_LIB_H_ */