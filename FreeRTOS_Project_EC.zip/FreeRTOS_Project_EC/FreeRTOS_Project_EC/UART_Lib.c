/*
 * USART_Lib.cpp
 *
 * Created: 10/13/2016 12:23:09 PM
 *  Author: heman
 */ 

#include "UART_Lib.h"

// USART initialization function
void UART_Init( uint8_t charSize, bool mode, bool parity, bool stopBits, bool polarity ) {
	
	// define baud rate
	UBRRH = BAUD>>8;
	UBRRL = BAUD;
	
	#if defined useDoubleSpeedMode
		UCSRA |= (1<<U2X);
	#endif
	
	// making high to use UCSRC register
	UCSRC |= (1<<URSEL); 
	
	// define character size to be sent
	if ( charSize > 4 ) {
		if ( charSize < 10 ) {
			switch ( charSize ) {		// see data-sheet for values
				case 5: {// Do nothing
					break;
				}
				case 6: {
					UCSRC |= (1<<UCSZ0);
					break;
				}
				case 7: {
					UCSRC |= (2<<UCSZ0);
					break;
				}
				case 8: {
					UCSRC |= (3<<UCSZ0);
					break;
				}
				case 9: {
					UCSRC |= (3<<UCSZ0);
					UCSRB |= (1<<UCSZ2);
					break;
				}
					
			}
		}
	}// if ends
	
	// set mode of communication, if true then use synchronous mode
	UCSRC |= mode == 1 ? (1<<UMSEL) : /* Do Nothing  */ UCSRC;
	if ( mode == 1 ) {
		UCSRC |= polarity == 1 ? (1<<CPOL) : /* Do Nothing */ UCSRC;
	}
	
	// set parity
	if ( parity >= 0 ) {
		if ( parity < 3 ) {
			UCSRC |= !parity ? /* Do Nothing */ UCSRC : parity==1 ? (1<<UPM1) : parity==2 ? ( (1<<UPM1) | (1<<UPM0) ) : /* Do Nothing */ UCSRC;
		}
	}
	
	// set stop bits
	UCSRC |= stopBits == 1 ? (1<<USBS) : /* Do Nothing */  UCSRC;
	
	// enable Tx and Rx
	UCSRB |= (1<<TXEN) | (1<<RXEN);
}// End


/*------------------- USART transmission function -----------------------------*/
void UART_Transmit ( const char data ) {
	// check for empty buffer
	while ( !(UCSRA & (1<<UDRE))  );		// wait
	UDR = data;			// put data into buffer
	// wait while data is not sent fully
	while( !(UCSRA & (1<<TXC)) );
}

void UART_Print ( const char *data ) {
	// send data using pointers
	for ( unsigned int i=0; data[i] != '\0' ; i++ ) {
		UART_Transmit(data[i]);
	}
}

void UART_PrintN ( const char *data, uint8_t len ) {
	// send data using pointers
	for ( uint8_t i=0; i<len; i++ ) {
		UART_Transmit(data[i]);
	}	
}


/*---------------- USART receiving functions ----------------------*/
char UART_Receive ( void ) {
	//wait while data is not received
	while( !(UCSRA & (1<<RXC)) );
	if ( !(UCSRA & (1<<FE)) )
	return UDR;
	return USARTDummy;
}


char * UART_Scan ( uint8_t length ) {
	
	// declare local and a pointer
	char *temp, *retAddress = NULL;
	uint8_t len;
	
	if ( (temp = (char *) malloc( sizeof(char) * (length+1) )) != NULL ) {		// +1 for '\0' to be appended at last
		// get starting address of memory allocated
		retAddress = temp;
		// start receiving
		for ( len=0; len<length; ++len ){
			*temp++ = UART_Receive();
		}
		*temp = '\0';		// append '\0' at last
	}
	else {
		UART_PrintN("No Memory\r\n", sizeof("NoMemory\r\n") );
	}
	
	// return address of temp
	return retAddress;
}

// receive number of characters from USART Rx pin
// have to use received buffer here itself
void UART_ScanN ( uint8_t length ) {
	// declare character pointer
	char temp[length+1];
	//set memory to '\0'
	memset( temp, '\0', sizeof(temp) );
	uint8_t len;
	// receive while terminating character is not received
	for ( len=0; len<length; ++len ){
		temp[len] = UART_Receive();
	}
	temp[len] = '\0';		// append '\0' at last
	UART_Print(temp);
}


void UART_PrintNumDynamic( uint16_t num )
{
	char temp[10];
	register uint8_t i = 0;
	
	do {
		temp[i++] = num%10 + '0' ;
		num /= 10;
	} while (num);
	
	while ( i ) {
		UART_Transmit( temp[--i] );
	}
}


void UART_PrintNum( uint16_t num ) {
	
	// convert to character and send
	if ( num >= 0 && num < 10 ) {
		UART_Transmit( num+48 );
	}
	else if ( num > 9 && num < 100 ) {
		UART_Transmit( (num/10)+48 );
		UART_Transmit( (num%10)+48 );
	}
	else if ( num > 99 && num < 1000 ) {
		UART_Transmit( (num/100)+48 );
		UART_Transmit( ((num%100)/10)+48 );
		UART_Transmit( ((num%10)%10)+48 );
	}
}

/*------------------------ USART Interrupt enable functions -------------------------*/
// select vary between 1 to 3 to define interrupt type
void UART_InterruptEnable ( uint8_t select ) {
	
	if ( select > 0 ) {
		if ( select < 4 ) {
			switch ( select ) {
				case 1:	{
					UCSRB |= (1<<RXCIE);		// receive complete interrupt
					break;
				}
				case 2:	{
					UCSRB |= (1<<TXCIE);		// transmission complete interrupt
					break;
				}
				case 3:	{
					UCSRB |= (1<<UDRIE);		// UDR empty interrupt
					break;
				}
			}
		}
	}
}