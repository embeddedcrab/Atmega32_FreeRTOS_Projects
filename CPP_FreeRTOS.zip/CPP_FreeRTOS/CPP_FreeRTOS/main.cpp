/*
 * CPP_FreeRTOS.cpp
 *
 * Created: 9/9/2017 11:29:39 PM
 * Author : heman
 */ 

/* Include standard headers. */
// Not Required

// include FreeRTOS files
#include "FreeRTOS_Files/FreeRTOS.h"
#include "FreeRTOS_Files/task.h"

/* Priority definitions for the tasks in the demo application. */
#define mainLED_TASK_PRIORITY			( tskIDLE_PRIORITY + 1 )

/* Handles For LED Blinking Task. */
TaskHandle_t xLEDTaskHandle = NULL;

/* Structure Declaration to handle data to be sent to task. */
typedef struct{
	volatile unsigned char * dir_port;
	volatile unsigned char * port;
	unsigned char data;
}xPortData_;


/************************************************************************/
/*                           Class for Task                             */
/************************************************************************/
class _Task{
	public:
		/* LED Blinking Function. */
		void vLED_Blinking( void * pvParameters );	
};

/************************************************************************/
/*                             Functions                                */
/************************************************************************/
/* Wrapper to call c++ function in c */
extern "C" {
	void vLED_TaskWrapper( void * pvParameters ) {
		/* Call function */
		(static_cast<_Task*>(pvParameters))->vLED_Blinking(pvParameters);
	}
};

/* Task Creation Function */
void vLED_BlinkingTask( UBaseType_t uxPriority, portSTACK_TYPE stackSize, void * data );

	

/*------------------------------ Main --------------------------------*/
int main(void)
{
	/* Data to be sent on port */
	xPortData_ portB  = { &DDRB, &PORTB, 0xFF };
		
    /* Call Task Creation function for LED Blinking. */
	vLED_BlinkingTask( mainLED_TASK_PRIORITY, configMINIMAL_STACK_SIZE, &portB );
	
	/* In this port, to use preemptive scheduler define configUSE_PREEMPTION
	as 1 in FreeRTOSConfig.h.  To use the cooperative scheduler define
	configUSE_PREEMPTION as 0. */
	vTaskStartScheduler();
	
	for ( ; ; );
	
	return 1;
}
/*---------------------------- Main ENDs -----------------------------*/



/*********************************************************
* Function Name : vLED_BlinkingTask
**
* Arguments:	uxPriority, stackSize
* Description : Task initializer.
*
*********************************************************/
void vLED_BlinkingTask( UBaseType_t uxPriority, portSTACK_TYPE stackSize, void * data ) {
	
	/* Create task */
	xTaskCreate( vLED_TaskWrapper, "LED_TASK", stackSize, data, uxPriority, &xLEDTaskHandle );
	configASSERT(xLEDTaskHandle);
	
	/* Using Handle to Delete the Task. */
	if( (xLEDTaskHandle) != NULL )
	{
		vTaskDelete(xLEDTaskHandle);
	}
}

/*********************************************************
* Function Name : vLED_Blinking
**
* Description : Blinks LED.
*
*********************************************************/
void _Task::vLED_Blinking( void * pvParameters ) {
	
	/* Initialize Port as output for LEDs. */
	portENTER_CRITICAL();
		/* Set Port properties. */
		*((static_cast<xPortData_ *>(pvParameters))->dir_port) = (static_cast<xPortData_ *>(pvParameters))->data;
		*((static_cast<xPortData_ *>(pvParameters))->port) = (static_cast<xPortData_ *>(pvParameters))->data;
	portEXIT_CRITICAL();

	/* Infinite loop */
	for ( ; ; ) {
		/* Set PORT pins as low */
		*((static_cast<xPortData_ *>(pvParameters))->port) &= ~((static_cast<xPortData_ *>(pvParameters))->data);
		/* Make program halt for 500ms */
		vTaskDelay(500);
		/* Set PORT pins as high */
		*((static_cast<xPortData_ *>(pvParameters))->port) = (static_cast<xPortData_ *>(pvParameters))->data;
		/* Make program halt for 500ms */
		vTaskDelay(500);
	}
}

