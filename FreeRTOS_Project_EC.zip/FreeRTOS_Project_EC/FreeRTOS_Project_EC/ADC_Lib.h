/*
 * ADC_Lib.h
 *
 * Created: 10/15/2016 12:12:05 PM
 *  Author: heman
 */ 


#ifndef ADC_LIB_H_
#define ADC_LIB_H_

#include <avr/io.h>

// uncomment if external voltage reference is selected
#define ADCExternalReferenceSelection		1
#define ADCLeftAdjustResult					0
#define ADCAutoTriggerEnable				0

// start function
extern void ADC_StartConversion ( void );
	
// initialization functions
extern void ADC_Init ( uint8_t prescaler );
		
// get value from adc channel function
extern uint16_t ADC_GetChannelValue ( uint8_t channel );
		
// interrupt enable function
extern void ADC_EnableInterrupt ( void );


#endif /* ADC_LIB_H_ */